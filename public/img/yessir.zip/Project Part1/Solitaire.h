#ifndef SOLITAIRE_H
#define SOLITAIRE_H

int tableauLineup(char* input);
int sortStock(char* input);
int sortTableau(char* input);
void mainMethod(char* argv[], int output);

extern char tDeck[7][2][13][2];
extern char fDeck[4][2];
extern char sDeck[2][30][2];

extern FILE* fp;
extern int part;
extern int turn;
extern int limit;

#endif

