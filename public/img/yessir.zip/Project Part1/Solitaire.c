#include <stdio.h> 
#include <errno.h> 
#include <string.h> 
#include <stdlib.h>
#include <ctype.h>
#include "Solitaire.h"

int tableauLineup(char* input);
int sortStock(char* input);
int sortTableau(char* input);

char tDeck[7][2][13][2];
char fDeck[4][2];
char sDeck[2][30][2];
int column = 6;
int wcount = 0;
int limit = -1;
int limitBool = 0;
FILE* fp;

int turn = 0;


int covered;
int stock;
int waste;
int stockBar = 0;
char tableauUncovered[100];
int rules = 0;
int foundations = 0;
int tableau = 0;
int stockC = 0;
const char* types = "A23456789TJQK";
const char* signs = "cshd";
int part = 0;



void mainMethod (char* argv[], int output){

    fp = stdin;

    if (argv[1] != NULL) {
        fp = fopen(argv[1], "r");
    }
    
    
    
    char line[100];
    char tableauLINE[100];
    char stockLINE[100];

  

    strcpy(tableauLINE, "");
    strcpy(stockLINE, "");


    covered = 0;
    stock = 0;
    waste = 0;
    int boolTab = 0;

    int lineCount = 0;
    while (part != 5 && fgets(line, 100, fp) != NULL) {

        char* split;

        split = strtok(line, " ");

        while (split)
        {

            if (split[0] == '#') {
                break;
            }

            else if (strcmp(split, "RULES:") == 0 || strcmp(split, "RULES:\n") == 0) {
                part = 1;
            }

            else if (strcmp(split, "FOUNDATIONS:") == 0 || strcmp(split, "FOUNDATIONS:\n") == 0) {
                if (part != 1) {
                    perror("Error! expecting 'RULES:'");
                    printf("Error near line %d: expecting 'RULES:'", lineCount - 1);
                    exit(EXIT_FAILURE);
                }

                part = 2;
            }

            else if (strcmp(split, "TABLEAU:") == 0 || strcmp(split, "TABLEAU:\n") == 0) {
                if (part != 2) {
                    perror("Error! Expecting 'FOUNDATIONS:'");
                    printf("Error near line %d: expecting 'FOUNDATIONS:'", lineCount - 1);
                    exit(EXIT_FAILURE);
                }
                
                part = 3;
            }

            else if (strcmp(split, "STOCK:") == 0 || strcmp(split, "STOCK:\n") == 0) {
                if (part != 3) {
                    perror("Error! Expecting 'TABLEAU:'");
                    printf("Error near line %d: expecting 'TABLEAU:'", lineCount - 1);
                    exit(EXIT_FAILURE);
                }
                
                
                part = 4;
            }

            else if (strcmp(split, "MOVES:") == 0 || strcmp(split, "MOVES:\n") == 0) {
                if (part != 4) {
                    perror("Error! Expecting 'STOCK:'");
                    printf("Error near line %d: expecting 'STOCK:'", lineCount - 1);
                    exit(EXIT_FAILURE);
                }
                
                
                
                part = 5;
                break;
            }

            else if (part == 1) {
            
                if (turn == 0 && isdigit(split[0])) {
                    turn = split[0] - '0';
                }
                
                if (limitBool == 1 && isdigit(split[0])) {
                    limit = split[0] - '0';
                }

                if (strcmp(split, "turn") == 0 ) {
                    rules++;
                }

                else if (strcmp(split, "unlimited\n") == 0 || strcmp(split, "unlimited") == 0){
                    rules++;
                    rules++;
                }

                else if (strcmp(split, "limit") == 0) {
                    rules++;
                    limitBool = 1;
                }
            
                else if (isdigit(split[0]) && !isdigit(split[1]) ) {
                    rules++;
                }
                
                else if (strcmp(split, "\n") != 0) {
                    perror("Error! Unknown/invalid phrase inputted!");
                    printf("Error! Unknown/invalid phrase inputted: %s", split);
                    exit(EXIT_FAILURE);
                }
            
            }
            
            else if (part == 2) {
                
                const char* valid = "_A23456789TJQK";
             
                if (rules != 4) {
                    perror("Error! Invalid rules format!");
                    printf("Error! Invalid rules format!");
                    exit(EXIT_FAILURE);
                }

                if (foundations == 0) {
                    if (strchr(valid, split[0]) == NULL && split[1] != 'c')
                    {
                        perror("Error! Invalid foundations format!");
                        printf("Error! Invalid foundations format!");
                        exit(EXIT_FAILURE);
                    }

                    fDeck[0][0] = split[0];
                    fDeck[0][1] = split[1];

                    //printf("FOUNDATION %d: %c%c\n", foundations, split[0], split[1]);

                    foundations++;

                }

                else if (foundations == 1) {
                    if (strchr(valid, split[0]) == NULL && split[1] != 'd')
                    {
                        perror("Error! Invalid foundations format!");
                        printf("Error! Invalid foundations format!");
                        exit(EXIT_FAILURE);
                    }

                    fDeck[1][0] = split[0];
                    fDeck[1][1] = split[1];

                   // printf("FOUNDATION %d: %c%c\n", foundations, split[0], split[1]);

                    foundations++;

                }

                else if (foundations == 2) {
                    if (strchr(valid, split[0]) == NULL && split[1] != 'h')
                    {
                        perror("Error! Invalid foundations format!");
                        printf("Error! Invalid foundations format!");
                        exit(EXIT_FAILURE);
                    }

                    fDeck[2][0] = split[0];
                    fDeck[2][1] = split[1];

                    //printf("FOUNDATION %d: %c%c\n", foundations, split[0], split[1]);

                    foundations++;

                }

                else if (foundations == 3) {
                    if (strchr(valid, split[0]) == NULL && split[1] != 's')
                    {
                        perror("Error! Invalid foundations format!");
                        printf("Error! Invalid foundations format!");
                        exit(EXIT_FAILURE);
                    }

                    fDeck[3][0] = split[0];
                    fDeck[3][1] = split[1];

                   // printf("FOUNDATION %d: %c%c\n", foundations, split[0], split[1]);

                    foundations++;

                }

                else {
                    if (strcmp(split, "\n") != 0) {
                        perror("Error! Invalid foundations format!");
                        printf("Error! Invalid foundations format!");
                        exit(EXIT_FAILURE);
                    }
                }
               
            }
           
            else if (part == 3) {  
                strcat(tableauLINE, " ");
                strcat(tableauLINE, split);
                boolTab = 1;
            }
            else if (part == 4) {
                strcat(stockLINE, " ");
                strcat(stockLINE, split);
            }
            else {
                
                if (strcmp(split, "\n") != 0) {
                    perror("Error! Unknown/invalid phrase inputted!");
                    printf("Error! Unknown/invalid phrase inputted: %s", split);
                    exit(EXIT_FAILURE);
                }
              
                break;
            }

            if (part != 5) {
                split = strtok(NULL, " ");
            }
        }
    
        if (part == 3 && boolTab == 1) {
            sortTableau(tableauLINE);
            strcpy(tableauLINE, "");
        }

        if (part == 4 || strcmp(stockLINE,"") != 0) {
            
            if (tableau != 7) {
                perror("Error! Incorrect number of tableau columns!");
                printf("Error! Incorrect number of tableau columns! There are %d columns.", tableau);
                exit(EXIT_FAILURE);
            }
            
            sortStock(stockLINE);
            strcpy(stockLINE, "");
        }


        lineCount++;
    }
	
    if (stockBar == 0) {
        perror("Error! Bar is missing in stock!");
        printf("Error! Bar is missing in stock!");
        exit(EXIT_FAILURE);
    }

    if (part != 5) {
        perror("Error! Moves: section is missing!");
        printf("Error! Moves: section is missing!");
        exit(EXIT_FAILURE);
    }

    if (output == 1) {

        printf("Input file is valid\n");
        printf("%d covered cards\n", covered);
        printf("%d stock cards\n", stock);
        printf("%d waste cards\n", waste);

    }
}



int sortTableau(char* input) {


    char* split;

    split = strtok(input, " ");

    int bar = 0;

    int row1 = 0;

    int row2 = 0;

    strcpy(tableauUncovered, "");

    while (split)
    {
        
        if (strcmp(split, "|") == 0 || strcmp(split, "|\n") == 0) {
            bar = 1;
            tableau++;
        }
        
        else if (strcmp(split, "\n") == 0) {

        }

        else if (bar == 0) {
           
            
            if (strchr(types, split[0]) == NULL || strchr(signs, split[1]) == NULL)
            {
                if (split != NULL) {
                    perror("Error! Invalid card entered!");
                    printf("Error! Invalid card entered: %s!", split);
                    exit(EXIT_FAILURE);
                }
            }
           
            
            covered++;

            tDeck[column][0][row1][0] = split[0];
            tDeck[column][0][row1][1] = split[1];

          // printf("TABLEAU COLUMN: %d TABLEAU ROW: %d VALUE: %c%c\n", column, row1, tDeck[column][0][row1][0], tDeck[column][0][row1][1]);

            row1++;
        }

        else if (bar == 1) {
            
            if (strchr(types, split[0]) == NULL || strchr(signs, split[1]) == NULL)
            {
                if (split != NULL) {
                    perror("Error! Invalid card entered!");
                    printf("Error! Invalid card entered: %s!", split);
                    exit(EXIT_FAILURE);
                }
            }
            
            
            strcat(tableauUncovered, " ");
            strcat(tableauUncovered, split);

            tDeck[column][1][row2][0] = split[0];
            tDeck[column][1][row2][1] = split[1];

          // printf("TABLEAU COLUMN: %d TABLEAU ROW: %d VALUE: %c%c\n", column, row2, tDeck[column][1][row2][0], tDeck[column][1][row2][1]);

            row2++;
        }


        split = strtok(NULL, " ");
    }

    if (bar == 0 && split != NULL) {
        perror("Error! Invalid tableau format!");
        printf("Error! Invalid tableau format! %s", input);
        exit(EXIT_FAILURE);
    }


    tableauLineup(tableauUncovered);

    if (bar != 0) {
        column--;
    }

}

int sortStock(char* input) {

    char* split;

    split = strtok(input, " ");

    int scount = 0;

    while (split)
    {

        if (strcmp(split, "|") == 0 || strcmp(split, "|\n") == 0) {
            stockBar = 1;
        }

        else if (strcmp(split, "\n") == 0) {

        }

        else if (stockBar == 0) {
            if (strchr(types, split[0]) == NULL || strchr(signs, split[1]) == NULL)
            {
                if (split != NULL) {
                    perror("Error! Invalid card entered!");
                    printf("Error! Invalid card entered: %s!", split);
                    exit(EXIT_FAILURE);
                }
            }

            sDeck[0][scount][0] = split[0];
            sDeck[0][scount][1] = split[1];

            //printf("WASTE %d: %s\n", scount, sDeck[0][scount]);

            scount++;
            waste++;
        }

        else if (stockBar == 1) {
            if (strchr(types, split[0]) == NULL || strchr(signs, split[1]) == NULL)
            {
                if (split != NULL) {
                    perror("Error! Invalid card entered!");
                    printf("Error! Invalid card entered: %s!", split);
                    exit(EXIT_FAILURE);
                }
            }

          sDeck[1][wcount][0] = split[0];
          sDeck[1][wcount][1] = split[1];

           

          //printf("STOCK %d: %s\n", wcount, sDeck[1][wcount]);
            
            wcount++;
            stock++;
        }

        split = strtok(NULL, " ");
    }


}

int tableauLineup(char* input) {
    
    char* split;
    
    split = strtok(input, " ");
    char match[2];
    char match2[2];
    int i = 0;


    while (split)
    {
        
        if (i != 0) {
            if ((split[0] != match[0] && split[1] != match[1]) && (split[0] != match2[0] && split[1] != match2[1])) {
                perror("Error! Invalid tableau lineup!");
                printf("Error! Invalid tableau lineup!");
                exit(EXIT_FAILURE);
            }
        }
        
        
        if (isdigit(split[0])) {
           
            if (split[0] == '2') {
                
                if (split[1] == 'c' || split[1] == 's') {
                    match[0] = 'A';
                    match[1] = 'h';

                    match2[0] = 'A';
                    match2[1] = 'd';
                }

                else if (split[1] == 'h' || split[1] == 'd') {     
                    match[0] = 'A';
                    match[1] = 'c';

                    match2[0] = 'A';
                    match2[1] = 's';
                }
            }
            
            else if (split[1] == 'c' || split[1] == 's') {
                int nb = (split[0] - '0') - 1;
                match[0] = nb + '0';
                match[1] = 'h';

                match2[0] = nb + '0';
                match2[1] = 'd';
            }

            else if (split[1] == 'h' || split[1] == 'd') {
                int nb = (split[0] - '0') - 1;
                match[0] = nb + '0';
                match[1] = 'c';

                match2[0] = nb + '0';
                match2[1] = 's';
            }


        }

        if (!isdigit(split[0])) {

            if (split[0] == 'K') {
              
                if (split[1] == 'c' || split[1] == 's') {
                    match[0] = 'Q';
                    match[1] = 'h';

                    match2[0] = 'Q';
                    match2[1] = 'd';
                }

                else if (split[1] == 'h' || split[1] == 'd') {
                    match[0] = 'Q';
                    match[1] = 'c';

                    match2[0] = 'Q';
                    match2[1] = 's';
                }


            }
            
            else if(split[0] == 'Q') {
                if (split[1] == 'c' || split[1] == 's') {
                    match[0] = 'Q';
                    match[1] = 'h';

                    match2[0] = 'Q';
                    match2[1] = 'd';
                }

                else if (split[1] == 'h' || split[1] == 'd') {
                    match[0] = 'J';
                    match[1] = 'c';

                    match2[0] = 'J';
                    match2[1] = 's';
                }
            }

            else if (split[0] == 'J') {
                if (split[1] == 'c' || split[1] == 's') {
                    match[0] = 'T';
                    match[1] = 'h';

                    match2[0] = 'T';
                    match2[1] = 'd';
                }

                else if (split[1] == 'h' || split[1] == 'd') {
                    match[0] = 'T';
                    match[1] = 'c';

                    match2[0] = 'T';
                    match2[1] = 's';
                }
            }
         
            else if (split[0] == 'T') {
                if (split[1] == 'c' || split[1] == 's') {
                    match[0] = '9';
                    match[1] = 'h';

                    match2[0] = 'T';
                    match2[1] = 'd';
                }

                else if (split[1] == 'h' || split[1] == 'd') {
                    match[0] = '9';
                    match[1] = 'c';

                    match2[0] = '9';
                    match2[1] = 's';
                }
            }
        }

        
            i++;
        split = strtok(NULL, " ");
    }





}



