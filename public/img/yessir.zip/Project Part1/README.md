For part 1 of the semester-long project, we we're supposed to be 
able to read from an input file that describes a game configuration 
(possibly in the middle of a game), make sure the input file is valid, 
and display summary information about the input file.

SAMPLE INPUT:

RULES: 
turn 1 
unlimited 
FOUNDATIONS: 
_c 
_d 
2h 
As 
TABLEAU:
8d 5c 7h Jd | Qs Jh Tc 
Ad 3h 4d 5s | 7d 6s 5d 4s 
7s Kd | 3s 
6h Qc 4h | 7c 
8s 2s | 4c 3d 2c 
| 
| Ks Qh Jc Td 
STOCK:
3c 8c | Th Kh 8h 
Qd 9s 6c Kc Ac Ts
Js 2d 
9h 6d 9c 5h 9d
MOVES:

SAMPLE OUTPUT:

Input file is valid
15 covered cards
16 stock cards
2 waste cards


----------------------------------------------------------------------

FEAUTURES IMPLEMENTED:

MAKEFILE:

A standard simple Makefile, in which typing "make" builds my check exectuable.


READING FROM STDIN IF NO FILENAME ARGUMENT:

Reads any given input through stdin when file name is not entered in arguments 
when running the check executable. For example: ./check < infile.txt


READING FROM FILENAME PASSED AS ARGUMENT:

Reads any given input file when filename is passed as argument when running the
check executable. For example: ./check infile.txt


NORMAL OUTPUT TO STDOUT:

Prints output to stdout when given a valid input file game. Prints if input file is
valid, covered cards, stock cards, and waste cards.


CORRECTLY FORMATTED OUTPUT ON VALID INPUTS:

Ouput of if input file is valid, covered cards, stock cards, and waste cards in the right
format. For example: 
Input file is valid
15 covered cards
16 stock cards
2 waste cards


REPORTS CORRECT NUMBER OF COVERED CARDS ON VALID INPUTS:

Reports how many covered cards which are the cards found to the left of the bar in 
the tableau section of input.


REPORTS CORRECT NUMBER OF STOCK CARDS ON VALID INPUTS:

Reports how many covered cards to stdout which are the cards found to the left of 
the bar in the tableau section of input.


REPORTS CORRECT NUMBER OF STOCK CARDS ON VALID INPUTS:

Reports how many stock cards to stdout which are the cards found to the right of 
the bar in the stock section of input.


REPORTS CORRECT NUMBER OF WASTE CARDS ON VALID INPUTS:

Reports how many stock cards to stdout which are the cards found to the left of 
the bar in the stock section of input.


NO ERROR ON VALID INPUTS:

Reports no type of error on any valid input, but outputs "Input file is valid".

Valid input formats are:

The RULES: 
�turn 1� or �turn 3�. 
�unlimited� or �limit N� where N is one of {0, 1, 2, . . . , 9}. 

The FOUNDATIONS: 
� The rank is one of { �A�, �2�, �3�, �4�, �5�, �6�, �7�, �8�, �9�, �T�, �J�, �Q�, �K� }.
� The suit is one of { �c�, �d�, �h�, �s� } (exact order)

The TABLEAU: 
� Zero or more covered cards.
� The �|� character, which serves to separate the covered cards from the uncovered ones.
� Zero or more uncovered cards.
� 7 columns.

The STOCK:
� Zero or more cards in the waste. 
� The �|� character, which serves to separate the waste from the stock.
� Zero or more cards in the stock.

The MOVES:
� End parsing when reached.


ERROR MESSAGES TO STDERR:

Prints out error messages when invalid input format, missing sections or invalid tableau lineup.
I print them to console as well.

FORMATTING ERROR MESSAGES INCLUDE LINE NUMBERS:

Prints out error messages to stderr when invalid format like missing sections, random words, 
invalid cards, or wrong/ made up rules like "turn A" or limit "A", with their respective line
numbers.

APPROPIATE ERROR MESSAGES FOR FORMATTING ERRORS:

Prints out appropiate error messages to stderr when invalid format like missing sections, random 
words, invalid cards, or wrong/ made up rules like "turn A" or limit "A", with their respective 
line numbers.

CHECK THAT THE TABLEAU PILES ARE LEGAL:

Prints an error when the lineup of the uncovered cards is wrong and not in decreasing order or 
of same color type. Every next card to the right in the uncovered section HAS to be of opposite 
color and of decreasing order in the hierarchy. 











