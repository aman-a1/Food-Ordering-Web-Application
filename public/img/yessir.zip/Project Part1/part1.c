#include <stdio.h> 
#include <errno.h> 
#include <string.h> 
#include <stdlib.h>
#include <ctype.h>
#include "Solitaire.h"


int main(int argc, char* argv[]) {
	
	mainMethod(argv, 1);
	
	return 0;
}
