#include <stdio.h> 
#include <stdlib.h> 
#include <math.h> 
#include <string.h>

unsigned* build_factors(unsigned N);
void show_array(unsigned* A);
unsigned* build_common(unsigned* A, unsigned* B);

/*
READ:

|
V

WHEN COMPILING ADD THE -lm TAG TO MAKE THE SQRT FUNCTION WORK.

EX: 'gcc -o hw4 HW4.c -lm'

FOR SOME REASON, MATH.H IS NOT SUFFICIENT IN PYRITE TESTING. THANKS.

NAME: ABDULA ELJAAM

NETID: ABELJAAM
*/


int main() {

    
    unsigned M; // holds the first unsigned int
    unsigned N; // holds the second unsigned int
    char input[30]; // holds the input scanned (the two unsigned ints) initially
    
    printf("Enter two integers M, N:\n");

    fgets(input, 30, stdin);


    char* pt;
    pt = strtok(input, ","); // splitting them by comma

    M = (unsigned int) atoi(pt);

    pt = strtok(NULL, ",");

    N = (unsigned int) atoi(pt);


    unsigned* Mfac = build_factors(M); // building factors of first number
    unsigned* Nfac = build_factors(N); // building factors of second number

    printf("%u has factors: ", M);
    show_array(Mfac); // printing factors string array
    
    printf("\n%u has factors: ", N);
    show_array(Nfac); // printing factors string array

    printf("\n%u and %u have common factors: ", M, N);
    show_array(build_common(Mfac,Nfac)); // building and then printing common factors of the two numbers.

    return 0;
}

unsigned* build_factors(unsigned N) {

    unsigned* prime; // represents the dynamic allocated array
    unsigned hold[256]; // holds the factors initially before dynamically copied to 'prime'
    int index = 0; // number of factors

    while (N % 2 == 0) //prints how many 2s that N can be divided in to to make N odd.
    {
        hold[index] = 2;
        N = N / 2;
        index++;
    }

    for (int i = 3; i <= sqrt(N); i = i + 2)
    {
        while (N % i == 0) // if i divides N we print i and then divide N (I skip one in i since number is odd)
        {
            hold[index] = i;
            N = N / i;
            index++;
        }
    }


    if (N > 2) { // if N is greater than 2 and a prime number itself
        hold[index] = N;
        index++;
    }

    hold[index] = 0;
    index++; //adding a zero to the end of the factor array

    prime = (unsigned*)malloc((index) * sizeof(unsigned)); //dynamically allocate the array with the exact number of factors used + the terminating zero.

    if (prime == NULL) { // if not allocated properly
        printf("Memory not allocated.\n");
        exit(0);
    }


    for (int i = 0; i < index; i++) { // copying the temporary array into the new dynamically allocated array
        prime[i] = hold[i];
    }

    return prime;
}


void show_array(unsigned* A) {

    int i = 0;

    while (A[i] != NULL) { // while the array has more

        if (A[i] == 0 && A[i + 1] != NULL) { //if the terminating zero is reached, i break the loop without printing it
            break;
     }

        else {
            if (i == 0) { // if first number i dont add a space before the numbern to match formatting of other show_array calls
                printf("%d", A[i]);
            }
            else {
                printf(", %d", A[i]);
            }
        }


        i++;
   }


}

unsigned* build_common(unsigned* A, unsigned* B) {

    int i = 0; // index while looping through first array
    unsigned hold[256]; // holds the common factors temporarily then dynamically allocate them.
    int o = 0; // index while looping through second array
    int size = 0; //number of common factors
    unsigned* finish; // the dynamically allocated array returned
    
    while (A[i] != NULL) { // while A has more

        if (A[i] != 0 && A[i + 1] != NULL) { //if not terminating zero
            while (B[o] != NULL) { // while B has more
                if (B[o] != 0 && B[o + 1] != NULL) { // if not terminating zero
                    if (A[i] == B[o]) { // if common factor is met
                        hold[size] = A[i]; //added to common factor array
                        size++; // increment size
                        o++; // increment b cursor to avoid rematching with that exact factor
                        break;
                    }
                }
                o++; // increment b cursor
            }

            if (B[o] == NULL) { // if end reached reset the pointer
                o = 0;
            }

        }

        i++; // increment A cursor
    }

    hold[size] = 0; // add terminating zero
    size++;

    finish = (unsigned*)malloc((size) * sizeof(unsigned)); //dynamically allocate the new array with the exact size of the bytes required for common factors

    if (finish == NULL) {
        printf("Memory not allocated.\n");
        exit(0);
    }


    for (int i = 0; i < size; i++) { //copying in the new dynamically allocated array from the temp one
        finish[i] = hold[i];
    }


    return finish;
}
