﻿
#include <stdio.h> 
#include <errno.h> 
#include <string.h> 
#include <stdlib.h>
#include <ctype.h>
#include "Solitaire.h"

char getLowerRank(char input);
char getOpposite2(char a);
char getOpposite1(char a);
char getHigherRank(char input);
void turn1();
void resetStock();
int lastWaste();
int lastTableauCovered(int row);
int lastTableauUncovered(int row);
int movesCt = 0;
int error = 0;
char errorMSG[4];
int rLimit = -1;
int rcount = 0;

int moveLimit = 9999999999;
int outType = 0;

char fileName[100];
char outputfileName[100];


char rank[] = {'A','2','3','4','5','6','7','8','9','T','J','Q','K'};

int main(int argc, char* argv[]) {
 
    int i = 1;

    while (*(argv+i) != NULL) {
        if (strcmp(*(argv + i), "-m") == 0) {
            i++;
            moveLimit = atoi(*(argv+i));

        }
        else if (strcmp(*(argv + i), "-o") == 0) {
            i++;
            strcpy(outputfileName, *(argv+i));
        }

        else if (strcmp(*(argv + i), "-x") == 0) {
            outType = 1;
        }
        else {
            strcpy(fileName, *(argv + i));
        }

        i++;
    }

    if (strcmp(fileName, "") != 0) {
        argv[1] = fileName;
    } 

    else {
        argv[1] = NULL;
    }

    mainMethod(argv, 0);
    
    char line[100];
    int part = 5;

    while (fgets(line, 100, fp) != NULL && error == 0) {

        char* split;

        split = strtok(line, " ");

        while (split)
        {
         
            
            //printf("%s\n", split);

            if (split[0] == '#') {
                break;
            }

            else if (part == 5) {
                
                if(split[2] == '>'){
                
                    if (split[0] == 'w') {
                        
                        if (isdigit(split[3])) {
                            movesCt++;

                            if (movesCt > moveLimit) {
                                break;
                            }

                            int x = split[3] - '0';

                            if (x >= 8 && x <= 0) {
                                fprintf(stderr, "Error: Invalid column entered! There is no column %d", x);
                                exit(EXIT_FAILURE);
                            }

                            int last = lastWaste();
                            char temp[2];         

                            if (sDeck[0][last][0] == NULL) {
                                strcpy(errorMSG, split);
                                error = 1;
                                break;
                            }

                            temp[0] = sDeck[0][last][0];
                            temp[1] = sDeck[0][last][1];

                            char higher = getHigherRank(temp[0]);
                            int lastTableau = lastTableauUncovered(x);

                            //printf("COMING FROM: %s\n", sDeck[0][last]);
                            //printf("MOVING TO: %s\n", tDeck[x - 1][1][last]);
                           // printf("HIGHER: %c\n", higher);
                            
                            if (tDeck[x - 1][1][lastTableau][0] != NULL && sDeck[0][last][0] != 'K') {

                                if (temp[1] == 'c' || temp[1] == 's') {
                                    if (tDeck[x - 1][1][lastTableau][0] != higher && (tDeck[x - 1][1][lastTableau][1] != 'h' || tDeck[x - 1][1][lastTableau][1] != 'd')) {
                                        strcpy(errorMSG, split);
                                        error = 1;
                                        break;
                                        //fprintf(stderr, "Error: Invalid Move! Card %s is not of higher rank and opposite type of card %s", tDeck[x - 1][1][lastTableau], temp);
                                       // exit(EXIT_FAILURE);
                                    }
                                }

                                else if (temp[1] == 'h' || temp[1] == 'd') {
                                    if (tDeck[x - 1][1][lastTableau][0] != higher && (tDeck[x - 1][1][lastTableau][1] != 'c' || tDeck[x - 1][1][lastTableau][1] != 's')) {
                                        strcpy(errorMSG, split);
                                        error = 1;
                                        break;
                                        //fprintf(stderr, "Error: Invalid Move! Card %s is not of higher rank and opposite type of card %s", tDeck[x - 1][1][lastTableau], temp);
                                       // exit(EXIT_FAILURE);
                                    }
                                }
                            }

                               

                            tDeck[x - 1][1][lastTableau + 1][0] = temp[0];
                            tDeck[x - 1][1][lastTableau + 1][1] = temp[1];
                            sDeck[0][last][0] =  '\0';


                       }
                        else if (split[3] == 'f') {
                            movesCt++;

                            if (movesCt > moveLimit) {
                                break;
                            }

                            
                            int last = lastWaste();
                            char temp[2];
                            
                            if (sDeck[0][last][0] == NULL) {
                                strcpy(errorMSG, split);
                                error = 1;
                                break;
                            }
                            
                            
                            temp[0] = sDeck[0][last][0];
                            temp[1] = sDeck[0][last][1];

                            char lower = getLowerRank(temp[0]);
                            

                            
                            if (temp[1] == 'c') {

                                if (fDeck[0][0] != lower && (fDeck[0][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    // fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank", temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                fDeck[0][0] = temp[0];
                                fDeck[0][1] = temp[1];
                               
                              
                            }

                            else if (temp[1] == 'd') {
                               
                                if (fDeck[1][0] != lower && (fDeck[1][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank", temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                
                                fDeck[1][0] = temp[0];
                                fDeck[1][1] = temp[1];
                            }

                            else if (temp[1] == 'h') {
                                
                                if (fDeck[2][0] != lower && (fDeck[2][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank", temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                
                                fDeck[2][0] = temp[0];
                                fDeck[2][1] = temp[1];
               
                            }

                            else if (temp[1] == 's' && (fDeck[3][0] != '_' || temp[0] != 'A')) {
                               

                                if (fDeck[3][0] != lower) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank", temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                fDeck[3][0] = temp[0];
                                fDeck[3][1] = temp[1];
                            }
                       
                            sDeck[0][last][0] = '\0';
                        }
                    
                    }

                    else if(isdigit(split[0])){
                        


                        int last = split[0] - '0';
                        
                        
                        if (isdigit(split[3])) {
                            movesCt++;

                            if (movesCt > moveLimit) {
                                break;
                            }


                            int last2 = split[3] - '0';

                            if (last >= 8 && last <= 0) {
                                fprintf(stderr, "Error: Invalid column entered! There is no column %d", last);
                                exit(EXIT_FAILURE);
                            }

                            if (last2 >= 8 && last2 <= 0) {
                                fprintf(stderr, "Error: Invalid column entered! There is no column %d", last2);
                                exit(EXIT_FAILURE);
                            }

                        
                            int x = lastTableauUncovered(last);
                            int y = lastTableauUncovered(last2);

                            char opp = getOpposite1(tDeck[last2 - 1][1][y][1]);
                            char opp2 = getOpposite2(tDeck[last2 - 1][1][y][1]);

                            char lower = getLowerRank(tDeck[last2 - 1][1][y][0]);

                            int moving = 0;
                            int index = -1;
                            
                            while (moving == 0 || index > x) {
                                index++;

                                
                                    if (tDeck[last2 - 1][1][y][0] == NULL && tDeck[last - 1][1][index][0] == 'K') {
                                        moving = 1;
                                    }

                               

                                   else if (tDeck[last - 1][1][index][0] == lower && (tDeck[last-1][1][index][1] == opp || tDeck[last - 1][1][index][1] == opp2)) {
                                     moving = 1;        
                                   }

                                    if (x < index && moving == 0) {
                                        break;
                                   }

                            }

                            if (moving != 1) {
                                strcpy(errorMSG, split);
                                error = 1;
                                break;
                                //fprintf(stderr, "Error: Invalid Move! Card %s is not of higher rank of any cards in row %d", tDeck[last2 - 1][1][y], last);
                                //exit(EXIT_FAILURE);
                            }



                            //printf("COMING FROM: %s\n", tDeck[last - 1][1][index]);
                            //printf("MOVING TO: %s\n", tDeck[last2 - 1][1][y]);
                            //printf("LOWER: %c\n", lower);
                            //printf("OPPOSITE 1: %c\n", opp);
                          // printf("OPPOSITE 2: %c\n", opp2);


                            char temp[2];
                            int p = index;
                            int q = y + 1;
                            
                           
                            while (p <= x) {
                                
                                temp[0] = tDeck[last - 1][1][p][0];
                                temp[1] = tDeck[last - 1][1][p][1];
                                

                                tDeck[last2 - 1][1][q][0] = temp[0];
                                tDeck[last2 - 1][1][q][1] = temp[1];
                                
                                tDeck[last - 1][1][p][0] = '\0';
                                p++;
                                q++;

                            }
                            
                        
                        }

                        if (split[3] == 'f') {
                            movesCt++;

                            if (movesCt > moveLimit) {
                                break;
                            }


                            if (last >= 8 && last <= 0) {
                                fprintf(stderr, "Error: Invalid column entered! There is no column %d", last);
                                exit(EXIT_FAILURE);
                            }

                            int lastTab = lastTableauUncovered(last);
                            char temp[2];

                            if (tDeck[last - 1][1][lastTab][0] == NULL) {
                                strcpy(errorMSG, split);
                                error = 1;
                                break;
                            }
                            
                            temp[0] = tDeck[last - 1][1][lastTab][0];
                            temp[1] = tDeck[last - 1][1][lastTab][1];
                            

                            char lower = getLowerRank(temp[0]);
                     
                          

                            if (temp[1] == 'c') {                                                                
                               
                                if (fDeck[0][0] != lower && (fDeck[0][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank of card %s", fDeck[0], temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                fDeck[0][0] = temp[0];
                                fDeck[0][1] = temp[1];

                                
                            }

                            if (temp[1] == 'd') {
                                
                                if (fDeck[1][0] != lower && (fDeck[1][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank of card %s", fDeck[1], temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                fDeck[1][0] = temp[0];
                                fDeck[1][1] = temp[1];
                            }

                            if (temp[1] == 'h') {
                                
                                
                                if (fDeck[2][0] != lower && (fDeck[2][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank of card %s LOWER: %c", fDeck[2], temp, lower);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                
                                fDeck[2][0] = temp[0];
                                fDeck[2][1] = temp[1];
                            }

                            if (temp[1] == 's') {
                                
                                if (fDeck[3][0] != lower && (fDeck[3][0] != '_' || temp[0] != 'A')) {
                                    strcpy(errorMSG, split);
                                    error = 1;
                                    break;
                                    //fprintf(stderr, "Error: Invalid Move! Card %s is not of lower rank of card %s", fDeck[3], temp);
                                    //exit(EXIT_FAILURE);
                                }
                                
                                
                                
                                fDeck[3][0] = temp[0];
                                fDeck[3][1] = temp[1];
                            }
                        
                            tDeck[last - 1][1][lastTab][0] = '\0';
                         
                        
                        }

                        if (tDeck[last-1][1][0][0] == NULL) {
                            int hold = lastTableauCovered(last);
                            char temp[2];
                            temp[0] = tDeck[last - 1][0][hold][0];
                            temp[1] = tDeck[last - 1][0][hold][1];
                            
                            tDeck[last - 1][1][0][0] = temp[0];
                            tDeck[last - 1][1][0][1] = temp[1];

                            tDeck[last - 1][0][hold][0] = '\0';
 
                        }

                       

                    }
                }

                else if (split[0] == '.') {
                    movesCt++;

                    if (movesCt > moveLimit) {
                        break;
                    }


                    if (turn == 1) {
                        turn1();

                        if (error == 1) {
                            break;
                        }
                    }
                    else if (turn == 3) {
                        turn3();

                        if (error == 1) {
                            break;
                        }
                    }
                }
                else if (split[0] == 'r') {
                   movesCt++;

                   if (movesCt > moveLimit) {
                       break;
                   }

                  resetStock();

                  if (error == 1) {
                      break;
                  }
                }
                else if(strcmp(split,"") != 0 && split[0] != NULL && strcmp(split,"\n") != 0) {
                     
                     fprintf(stderr, "Error: Unknown move entered! Move: %s", split);
                     exit(EXIT_FAILURE);
                 }
                    

                split = strtok(NULL, " ");

            }


        }



    }

    if (outType == 0) {
        printOutput();
    }

    if (outType == 1) {
        printOutput2();
    }
    

}

int lastWaste() {
    
    int i = 0;

    while (sDeck[0][i][0] != NULL) {
        i++;
    }

    
    i--;
    
    return i;
    
}

int lastTableauCovered(int row) {
    int i = 0;

    while (tDeck[row - 1][0][i][0] != NULL) {
        i++;
    }

    i--;

    return i;
}

int lastTableauUncovered(int row) {
    int i = 0;

    while (tDeck[row - 1][1][i][0] != NULL) {
        i++;
    }

    i--;

    return i;
}

int lastStock() {
    int i = 0;

    while (sDeck[1][i][0] != NULL) {
        i++;
    }


    i--;

    return i;
}


void resetStock() {

    rcount++;
    
    
    if (sDeck[1][0][0] != NULL) {
        strcpy(errorMSG, "r");
        error = 1;
        return;
    }
    


    if (limit != -1 && limit+1 <= rcount) {
        strcpy(errorMSG, "r");
        error = 1;
        return;
    }

    
        int i = 0;


        while (sDeck[0][i][0] != NULL) {
            char temp[2];
            temp[0] = sDeck[0][i][0];
            temp[1] = sDeck[0][i][1];

            sDeck[1][i][0] = temp[0];
            sDeck[1][i][1] = temp[1];

            sDeck[0][i][0] = '\0';
            i++;
        }
    
 
  
}

void turn3() {

    int last = lastWaste();
    int lastSt = lastStock();

    if (sDeck[1][0][0] == NULL || sDeck[1][1][0] == NULL || sDeck[1][2][0] == NULL) {
        strcpy(errorMSG, ".");
        error = 1;
        return;
    }

   
    //printf("STOCK INDEX 0: %s\n", sDeck[1][0]);
    //printf("LAST STOCK INDEX: %d\n", lastSt);
    
    sDeck[0][last + 1][0] = sDeck[1][0][0];
    sDeck[0][last + 1][1] = sDeck[1][0][1];

    sDeck[0][last + 2][0] = sDeck[1][1][0];
    sDeck[0][last + 2][1] = sDeck[1][1][1];

    sDeck[0][last + 3][0] = sDeck[1][2][0];
    sDeck[0][last + 3][1] = sDeck[1][2][1];


    for (int i = 1; i <= lastSt; i++) {
        
        sDeck[1][i - 1][0] = sDeck[1][i][0];
        sDeck[1][i - 1][1] = sDeck[1][i][1];


        if (i == lastSt) {
            sDeck[1][i][0] = '\0';
        }
       
    }

    for (int i = 1; i <= lastSt; i++) {

        sDeck[1][i - 1][0] = sDeck[1][i][0];
        sDeck[1][i - 1][1] = sDeck[1][i][1];


        if (i == lastSt) {
            sDeck[1][i][0] = '\0';
        }

    }

    for (int i = 1; i <= lastSt; i++) {

        sDeck[1][i - 1][0] = sDeck[1][i][0];
        sDeck[1][i - 1][1] = sDeck[1][i][1];


        if (i == lastSt) {
            sDeck[1][i][0] = '\0';
        }

    }

    //printf("First Stock: %c%c\n", sDeck[1][0][0], sDeck[1][0][1]);

    
}

void turn1() {

    int last = lastWaste();
    int lastSt = lastStock();

    if (sDeck[1][0][0] == NULL) {
        strcpy(errorMSG, ".");
        error = 1;
        return;
    }


    //printf("STOCK INDEX 0: %s\n", sDeck[1][0]);
    //printf("LAST STOCK INDEX: %d\n", lastSt);

    sDeck[0][last + 1][0] = sDeck[1][0][0];
    sDeck[0][last + 1][1] = sDeck[1][0][1];


    for (int i = 1; i <= lastSt; i++) {

        sDeck[1][i - 1][0] = sDeck[1][i][0];
        sDeck[1][i - 1][1] = sDeck[1][i][1];


        if (i == lastSt) {
            sDeck[1][i][0] = '\0';
        }

    }

    //printf("First Stock: %c%c\n", sDeck[1][0][0], sDeck[1][0][1]);

}

char getLowerRank(char input) {
    char ret;

    for (int i = 0; i < 13; i++) {

        if (rank[i] == input) {

            if (input == 'A') {
                ret = '_';
            }

            else {
                ret = rank[i - 1];
            }


        }

    }


    return ret;

}

   char getHigherRank(char input) {
        char ret;

        for (int i = 0; i < 13; i++) {

            if (rank[i] == input) {

                if (input == 'K') {
                    ret = 'A';
                }

                else {
                    ret = rank[i + 1];
                }


            }

        }


        return ret;
    }


   char getOpposite1(char a) {

       if (a == 'c' || a == 's'){
         return 'h';
      }

      else {
      return 'c';
      }

   }

   char getOpposite2(char a) {

       if (a == 'c' || a == 's'){
           return 'd';
   }

      else {
      return 's';
      }

   }

   void printOutput() {

       if (error == 0) {
           printf("Processed %d moves, all valid\n", movesCt);
       }
       else if (error != 0) {
           printf("Move %d is illegal: %s\n", movesCt, errorMSG);
       }
       
       printf("Foundations\n");
       
           for (int i = 0; i < 4; i++) {
               if (i != 3) {
                   printf("%c%c ", fDeck[i][0], fDeck[i][1]);
               }
               else {
                   printf("%c%c\n", fDeck[i][0], fDeck[i][1]);
               }
           }
           printf("Tableau\n");

           int max = 0;

           for (int j = 1; j < 8; j++) {
               int pk = lastTableauCovered(j) + 1;
               int gq = lastTableauUncovered(j) + 1;

               if ((pk + gq) > max) {
                   max = pk + gq;
               }
           }


           int temp = 0;
           int temp2 = 0;
           int temp3 = 0;
           int temp4 = 0;
           int temp5 = 0;
           int temp6 = 0;
           int temp7 = 0;


           for (int i = 0; i < max; i++) {

               int last1 = lastTableauCovered(1);
               int last2 = lastTableauUncovered(1);

               if (i <= last1) {
                   printf("## ");
               }

               else if (temp <= last2) {
                   printf("%c%c ", tDeck[0][1][temp][0], tDeck[0][1][temp][1]);
                   temp++;
               }

               else if (temp > last2) {
                   printf(".. ");
               }

               int last3 = lastTableauCovered(2);
               int last4 = lastTableauUncovered(2);

               if (i <= last3) {
                   printf("## ");
               }

               else if (temp2 <= last4) {
                   printf("%c%c ", tDeck[1][1][temp2][0], tDeck[1][1][temp2][1]);
                   temp2++;
               }

               else if (temp2 > last4) {
                   printf(".. ");
               }

               int last5 = lastTableauCovered(3);
               int last6 = lastTableauUncovered(3);

               if (i <= last5) {
                   printf("## ");
               }

               else if (temp3 <= last6) {
                   printf("%c%c ", tDeck[2][1][temp3][0], tDeck[2][1][temp3][1]);
                   temp3++;
               }

               else if (temp3 > last6) {
                   printf(".. ");
               }

               int last7 = lastTableauCovered(4);
               int last8 = lastTableauUncovered(4);

               if (i <= last7) {
                   printf("## ");
               }

               else if (temp4 <= last8) {
                   printf("%c%c ", tDeck[3][1][temp4][0], tDeck[3][1][temp4][1]);
                   temp4++;
               }

               else if (temp4 > last8) {
                   printf(".. ");
               }

               int last9 = lastTableauCovered(5);
               int last10 = lastTableauUncovered(5);

               if (i <= last9) {
                   printf("## ");
               }

               else if (temp5 <= last10) {
                   printf("%c%c ", tDeck[4][1][temp5][0], tDeck[4][1][temp5][1]);
                   temp5++;
               }

               else if (temp5 > last10) {
                   printf(".. ");
               }


               int last11 = lastTableauCovered(6);
               int last12 = lastTableauUncovered(6);

               if (i <= last11) {
                   printf("## ");
               }

               else if (temp6 <= last12) {
                   printf("%c%c ", tDeck[5][1][temp6][0], tDeck[5][1][temp6][1]);
                   temp6++;
               }

               else if (temp6 > last12) {
                   printf(".. ");
               }



               int last13 = lastTableauCovered(7);
               int last14 = lastTableauUncovered(7);

               if (i <= last13) {
                   printf("##\n");
               }

               else if (temp7 <= last14) {
                   printf("%c%c\n", tDeck[6][1][temp7][0], tDeck[6][1][temp7][1]);
                   temp7++;
               }

               else if (temp7 > last14) {
                   printf("..\n");
               }





           }



           printf("Waste top\n");


           if (sDeck[0][0][0] == NULL) {
               printf("(empty)\n");
           }

           else {
               int lastW = lastWaste();

               printf("%c%c\n", sDeck[0][lastW][0], sDeck[0][lastW][1]);
           }





       
   }


   void printOutput2() {
   
       if (error == 0) {
           printf("Processed %d moves, all valid\n", movesCt);
       }
       else if (error != 0) {
           printf("Move %d is illegal: %s\n", movesCt, errorMSG);
       }
       
      printf("RULES:\n");

      printf("  turn 1\n");

      if (limit == -1) {
          printf("  unlimited\n");
      }

      else {
          printf("  limit %d\n", limit);
      }

      printf("FOUNDATIONS:\n");

      printf("  %c%c\n", fDeck[0][0], fDeck[0][1]);
      printf("  %c%c\n", fDeck[1][0], fDeck[1][1]);
      printf("  %c%c\n", fDeck[2][0], fDeck[2][1]);
      printf("  %c%c\n", fDeck[3][0], fDeck[3][1]);

      printf("TABLEAU:\n");

      int i = 6;

      while (i > -1) {

          int last = lastTableauCovered(i + 1);

          int j = 0;

          while (j <= last) {
              if (j == 0) {
                  printf("  %c%c ", tDeck[i][0][j][0], tDeck[i][0][j][1]);
              }

              else {
                  printf("%c%c ", tDeck[i][0][j][0], tDeck[i][0][j][1]);
              }
              j++;
          }

          if (last == -1) {
              printf("  | ");
          }
          else {
              printf("| ");
          }


          int last2 = lastTableauUncovered(i + 1);
          int z = 0;

          while (z <= last2) {
              printf("%c%c ", tDeck[i][1][z][0], tDeck[i][1][z][1]);
              z++;
          }

          printf("\n");

          i--;

      }

      printf("STOCK:\n");

      int q = 0;
      int lastW = lastWaste();

      while (q <= lastW) {
          printf("%c%c ", sDeck[0][q][0], sDeck[0][q][1]);
          q++;
      }

      printf("| ");

      int d = 0;
      int lastS = lastStock();

      while (d <= lastS) {
          printf("%c%c ", sDeck[1][d][0], sDeck[1][d][1]);
          d++;
      }


      printf("\n");

      printf("MOVES:");


   }


