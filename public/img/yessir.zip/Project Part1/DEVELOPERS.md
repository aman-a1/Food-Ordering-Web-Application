For part 1 of the semester-long project, we we're supposed to be 
able to read from an input file that describes a game configuration 
(possibly in the middle of a game), make sure the input file is valid, 
and display summary information about the input file.

OVERVIEW:

I implented this part of the project mainly in the main function, with three supporting functions
to help sort the tableau section and stock section. I basically ran a huge while loop that scans 
the input file line by line, and then split each line by whitespaces in an inner while loop. After
that, I had numerous if statements that check what section we're currently working with. For each
respective section I evaluate the input to find errors. In the sortTableau function I just count 
the covered cards by sending in whatever line while im in the TABLEAU section as a parameter. In 
the sortStock function I really just count the stock and waste cards, by sending in whatever lines
while in the STOCK section as a parameter. In the tableauLineup function I just parse each line 
that is found in the uncovered part of the input and check if it is opposite color and in 
decreasing order. That is the simple overview of my code, now on to the function breakdowns.


ALL FUNCTIONS:


int main(int argc, char *argv[]) :

I start off with checking if there is a file passed as an argument. If there isn't I just read from
stdin. I then make an empty string called line that will be holding each line respectively while
parsing. I run a while loop until the line is null or moves section is reached. I then run another
while loop that splits the line by whitespaces and stores them in the string split. Whenever a section
is reached, I change increment the part variable. If part is 1, I check if turn 1 or 3 is there, and if
unlmited or limit 1 is there. If one isn't found I output an error. If part is 2, I check that the 
foundations are in the correct order and that they're valid cards. If part is 3, I add whatever is on
the line to a string called tableauLINE, and after the line is finished I send it to sortTableau and 
empty tableauLine so it can be used again. If part is 4, I essentially do the same as part 3. I add the
line to stockLINE and then after the line is done send it to sortStock and then empty it. If part is 5,
the outer while loop breaks. I then check if the variable stockBar is 0 then output an error that means
that there was no bar in the stock section. After that I output the covered, stock and waste cards.

int sortTableau(char* input): 

This function is used to count the number of covered cards, and send the uncovered cards to tableauLineup
I start this function off with a basic split by whitespace while loop. I have a variable called bar which
basically helps me indicate if we're dealing with covered or uncovered cards. If bar is 0 that means that
the bar hasn't occured yet, so I increment covered cards. I also check if card is valid in that if statement, 
by comparing first character with all valid types and second character with all valid cards. If bar is 1,
I add that card to tableauUncovered which is a string that holds all the uncovered cards in THAT specific 
line. After the while loop is done, I send the tableauUncovered to tableauLineup to verify its lineup 
validity.

int sortStock(char* input):

This function is used to count the number of stock and waste cards. This function is VERY similair to 
sortTableau. I run a while loop that splits up the line by whitespace. I have a stockBar int that is 0 when
bar hasn't passed yet, or 1 when passed. When bar is 0, I increment waste cards. When bar is 1, I increment
stock cards. For BOTH if statements I check validity of cards by using strchr of first charcter with cards
and second character with types.

int tableauLineup(char* input) (BONUS 1):

This is the function where I check if the tableau lineup is legal for all seven columns. The function is 
ran every tableau line, and is passed as an argument input. I run a while loop that splits input based on
whitespace. I DO NOT check the first cards validity as it declares what starts. After that I check the first
char with many different if statements to check what number or letter card it is. After I know what number it
is, I check what type it is. For each card I store two potiental matches for it, one is the lower ranking card
with opposite color type 1, the other is lower ranking card type 2. For each card, I check if it matches with
either match or match2, if not then I output an error.



